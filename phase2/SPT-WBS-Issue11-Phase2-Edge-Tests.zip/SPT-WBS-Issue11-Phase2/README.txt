SPT-WBS Issue #11 Phase 2 Edge Tests
TEST-ONLY. Use only an empty disposable folder, never a live/company workbook folder.

1. Open SPT-WBS-FS-Phase2.html locally with Microsoft Edge (file://).
2. Select a NEW disposable empty folder and install the bundled synthetic fixtures.
3. Run FS-04 (permission persistence: refresh and full restart), FS-06 (Excel locking on disposable fixture), and FS-07 (external-change detection).
4. Copy the test log and provide it for evaluation against Issue #11.

The three .xlsx files are disposable synthetic fixtures. The harness can install its own fresh fixtures using embedded identical bytes.
A successful write while Excel has the workbook open is a RISK finding, not proof of safe locking.
No product changes, architecture acceptance, or deployment authorized.
