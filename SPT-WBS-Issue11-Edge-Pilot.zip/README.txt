# SPT-WBS Issue #11 — Actual Windows 11 / Edge pilot (TEST ONLY)

This package is a **synthetic, standalone filesystem probe**, NOT the managed application and NOT production Save. It is intended to collect first-hand evidence for a SUBSET of FS-01/03/05/07. All other FS-01–FS-12 tests remain pending until performed and independently reviewed. Nothing is sent over a network.

## Before starting

1. Use a **Windows 11 / Microsoft Edge** machine. Extract this ZIP in a *new, disposable local NTFS folder*, e.g. `C:\Temp\spt-wbs-fs-pilot-01`. Do NOT use a real project/OneDrive folder.
2. The extracted directory must contain both xlsx files and the HTML. **Close both in Excel before clicking the write test**.
3. Double-click `SPT-WBS-Windows-Edge-FS-Pilot.html`, open it in Microsoft Edge, and verify the address begins `file:///`.
4. Click **Check environment**, **Select disposable test folder**, and select the extracted directory. Then **Inspect synthetic fixtures**. If unsupported/blocked, capture the exact error. Do not bypass corporate policy.
5. If valid, click **Perform guarded write test**. This creates the previously nonexistent `SPT-WBS-FS-TEST.backup.xlsx` then overwrites ONLY the synthetic `SPT-WBS-FS-TEST.xlsx` with prebuilt synthetic candidate bytes. All writes are read back and SHA-256 checked. The app refuses existing backup collisions and unrecognized source/candidate content.
6. Open both `SPT-WBS-FS-TEST.xlsx` and `SPT-WBS-FS-TEST.backup.xlsx` in desktop Excel after the run. Verify source Progress=80 and UpdateHistory entry; backup Progress=60 and no history. Record any Excel repair warnings.
7. Copy the log and record Windows build, Edge version, Excel version, local versus synced disk, observed results, and any screenshots. Share redacted results to the project conversation/Issue #11 **only after review**.

## Expected SHA-256

- Original: `e1a78ee11371035ef75c1d81786a6ebd19fc0bcebd99c3a067dc8cf64f369deb`
- Candidate: `53abbf1c9333d7b7a4d47e603556ade62cc573b2e0b1aae347b12bf8fad527a9`

## What these tests do NOT prove

- No ExcelJS mutation/round-trip, unknown OOXML fidelity, formula cache correction, real app field/history transaction code, or Save As activation.
- No rollback or crash-consistent/atomic guarantees; the browser cannot guarantee cross-file atomicity.
- No full FS-01–FS-12 acceptance, no Excel-open universal lock detection, no backup rotation safety, no conflict UI, no disk-full injection.
- In particular, **this probe must not be called a PASS for Issue #11 as a whole**. Run the official issue-11 runbook for the remaining cases with a separate, approved test-only harness and independent QA.

**Governance:** no code modification to the v18/read-only product, no GitHub mutation/PR merge/implementation approval and no company data.
